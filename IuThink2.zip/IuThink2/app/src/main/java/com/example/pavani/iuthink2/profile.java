package com.example.pavani.iuthink2;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v7.widget.Toolbar;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class profile extends AppCompatActivity {
    private static final String tag="profile";
    private Context mc=profile.this;
    private static final int actnum=4;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        bottomnav();
        settb();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void settb()
    {
        Toolbar toolbar=(Toolbar)findViewById(R.id.topprofiletb);
        setSupportActionBar(toolbar);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.profmenu:
                        break;
                }
                return false;
            }
        });
    }
    private void  bottomnav()
    {
        BottomNavigationViewEx bottomNavigationViewEx=(BottomNavigationViewEx)findViewById(R.id.bottomshelfbnv);
        bottomnavhelper.bottomnav(bottomNavigationViewEx);
        bottomnavhelper.ennav(mc,bottomNavigationViewEx);
        Menu menu=bottomNavigationViewEx.getMenu();
        MenuItem menuItem=menu.getItem(actnum);
        menuItem.setChecked(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.profmen,menu);
        return true;
    }
}
