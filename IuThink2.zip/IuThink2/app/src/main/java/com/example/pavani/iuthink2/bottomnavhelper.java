package com.example.pavani.iuthink2;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.view.MenuItem;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class bottomnavhelper {
    private static final String tag="bottomnavhelper";
    public static void bottomnav(BottomNavigationViewEx bottomNavigationViewEx)
    {
        bottomNavigationViewEx.enableAnimation(false);
        bottomNavigationViewEx.enableItemShiftingMode(false);
        bottomNavigationViewEx.enableShiftingMode(false);
        bottomNavigationViewEx.setTextVisibility(false);
    }
    public static  void ennav(final Context context, BottomNavigationViewEx v)
    {
        v.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.house:
                        Intent home=new Intent(context,Home.class);
                        context.startActivity(home);
                        break;
                    case R.id.search:
                        Intent search=new Intent(context, search.class);
                        context.startActivity(search);
                        break;
                    case R.id.circle:
                        Intent share=new Intent(context, share.class);
                        context.startActivity(share);
                        break;
                    case R.id.alert:
                        Intent likes= new Intent(context, likes.class);
                        context.startActivity(likes);
                        break;
                    case R.id.android:
                        Intent profile=new Intent(context,profile.class);
                        context.startActivity(profile);
                        break;
                }
                return false;
            }
        });
    }
}
