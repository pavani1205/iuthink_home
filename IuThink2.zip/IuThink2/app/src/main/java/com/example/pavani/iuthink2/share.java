package com.example.pavani.iuthink2;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class share extends AppCompatActivity {
    private static final String tag="share";
    private Context mc=share.this;
    private static final int actnum=2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
    private void  bottomnav()
    {
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomshelfbnv);
        bottomnavhelper.bottomnav(bottomNavigationViewEx);
        bottomnavhelper.ennav(mc, bottomNavigationViewEx);
        Menu menu=bottomNavigationViewEx.getMenu();
        MenuItem menuItem=menu.getItem(actnum);
        menuItem.setChecked(true);
    }
}
