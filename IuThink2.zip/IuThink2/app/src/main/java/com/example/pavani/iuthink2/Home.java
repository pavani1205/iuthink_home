package com.example.pavani.iuthink2;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class Home extends AppCompatActivity {
    private static final String tag="Home";
    private Context mc= Home.this;
    private final int actnum=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bottomnav();
        viewpager();
    }

    private void viewpager()
   {
       spageadapter adapter=new spageadapter(getSupportFragmentManager());
       adapter.addfragment(new camerafragment());
       adapter.addfragment(new homefragment());
       ViewPager viewPager=(ViewPager)findViewById(R.id.centerpagevp);
      viewPager.setAdapter(adapter);
        TabLayout tabLayout=(TabLayout)findViewById(R.id.topshelftb);
        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setIcon(R.drawable.ic_camera);
        tabLayout.getTabAt(1).setIcon(R.drawable.iuthink1);
    }
    private void  bottomnav()
    {
        BottomNavigationViewEx bottomNavigationViewEx=(BottomNavigationViewEx)findViewById(R.id.bottomshelfbnv);
        bottomnavhelper.bottomnav(bottomNavigationViewEx);
        bottomnavhelper.ennav(mc,bottomNavigationViewEx);
        Menu menu=bottomNavigationViewEx.getMenu();
        MenuItem menuItem=menu.getItem(actnum);
        menuItem.setChecked(true);
    }


}
