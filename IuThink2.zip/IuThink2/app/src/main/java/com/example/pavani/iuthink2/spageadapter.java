package com.example.pavani.iuthink2;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class spageadapter extends FragmentPagerAdapter{
    private static final String tag="spageadapter";

    private final List<Fragment> fragmentList=new ArrayList<>();

    public spageadapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }
    public void addfragment(Fragment fragment)
    {
        fragmentList.add(fragment);
    }

}
